# NCS-system
PID 参数：
8.19
Kp=23.16; Kd=3.007; Ki=36.42.
